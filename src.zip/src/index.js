import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Sign from './components/Sign';
import Reset from "./components/Reset"




const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<App />} />
        <Route path='sign' element={<Sign />} />
        <Route path='reset' element={<Reset />} />


      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);


