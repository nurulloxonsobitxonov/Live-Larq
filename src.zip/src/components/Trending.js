import React from 'react'
import black from "../images/black.jpg"
import white from "../images/white.jpg"
import blue from "../images/blue.jpg"

function Trending() {

    const style = {
        h1: "text-[#153A5B] font-bold text-[60px] justify-center flex items-center",
        li: "w-[65px] flex h-[7.5px] bg-[#F3756D] mx-[48%] my-[27px]",
        big_div: " grid grid-cols-3 my-[140px] gap-[-50px]",
        div1: "w-[250px] mx-[90px] my-[60px]",
        div2: "w-[300px] mx-[120px]",
        div3: "w-[500px] translate-y-[-120px]",
        bigger_div: "w-[450px] h-[450px] my-[-30px] mx-[30px] hover:bg-[#A1B0BD] duration-500 relative group truncate",
        ldiv: "absolute top-[140px]",
        select_h1: "text-[#E1E5EA] text-[20px] font-bold translate-x-[-250px] translate-y-[270px] group-hover:translate-x-[90px] duration-500",
        size1: "w-[130px] h-[70px] border-white rotate-90  border-[3px] translate-x-[-95px] font-bold text-[25px] text-white justify-center items-center flex hidden group-hover:block duration-500 hover:bg-[#ffffff] hover:text-[#153A5B] cursor-pointer",
        size2: "w-[130px] h-[70px] border-white text-white rotate-90  border-[3px] translate-x-[115px] font-bold text-[25px]  hidden  group-hover:block duration-500 hover:bg-[#ffffff] hover:text-[#153A5B] cursor-pointer",

    }

    return (
        <div>
            <h1 className={style.h1}>Trending now</h1>
            <li className={style.li}></li>
            <div className={style.big_div}>
                <div className={style.bigger_div}>
                    <div className={style.div1}><img src={blue} alt="" />
                        <div className={style.ldiv}>
                            <h1 className={style.select_h1}>Select size:</h1>
                            <div className='flex mx-[-20px] my-[40px]'>
                                <h1 className={style.size1}>17 oz</h1> <h1 className={style.size2}>25 oz</h1>
                            </div>

                        </div>

                    </div>

                </div>
                <div className={style.bigger_div}>
                    <div className={style.div2}>
                        <img className="w-[250px] my-[40px]" src={black} alt="" />
                        <div className={style.ldiv}>
                            <h1 className={style.select_h1}>Select size:</h1>
                            <div className='flex mx-[-20px] my-[40px]'>
                                <h1 className={style.size1}>17 oz</h1> <h1 className={style.size2}>25 oz</h1>
                            </div>

                        </div>
                    </div>
                </div>
                <div className="w-[550px] h-[450px] my-[-30px] hover:bg-[#A1B0BD] duration-500">
                    <div className={style.div3}>
                        <img className='w-[450px] h-[400px] translate-y-[150px] mx-[55px] justify-center items-center flex' src={white} alt="" />
                    </div>
                </div>

            </div>
        </div>
    )
}

export default Trending