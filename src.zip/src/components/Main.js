import React, { useState } from 'react'
import { TbDisabled } from "react-icons/tb"
import { HiOutlineXMark } from "react-icons/hi2"


function Main() {
    const [click, setclick] = useState(false)


    const style = {
        main: "main ",
        li: "text-[50px]  w-[580px] text-white translate-x-[80px] translate-y-[170px] font-bold  max-md:text-[24px] h-[30px] w-[280px]  flex flex-col translate-x-[35px] translate-y-[20px] ",
        p: "text-[25px] text-white translate-y-[350px] px-[80px] max-md:text-[10.9px] w-[670px] translate-x-[-50px] font-bold  translate-y-[300px]",
        li1: "group text-white text-[20px] font-bold w-[240px] h-[50px] bg-[#153A5B] list-none absolute top-[500px] mx-[80px] flex items-center justify-center z-10 hover:bg-white  cursor-pointer group hover:text-[#153A5B] duration-500 max-md:w-[200px] translate-x-[-30px] translate-y-[110px]",
        li2: " w-[240px] h-[50px] border-[#153A5B] border-[3px] list-none my-[385px] mx-[90px] z-auto max-md:w-[200px] translate-x-[-30px] translate-y-[70px]",
        disable_div: `w-[700px] h-[780px] rounded-2xl bg-red-300 absolute left-[35px] top-[30px] z-10 overflow-visible duration-500 ${click ? 'hidden' : 'block'}`,
        person_div: " w-[60px] sticky translate-x-[96pc] translate-y-[-16pc] h-[60px] rounded-[50%] bg-[#146ff8] hover:scale-[1.1] duration-500 cursor-pointer",
        person: "text-white text-[40px]   mx-[10px] translate-y-[9px]"

    }

    return (
        <div>
            <div className={style.main}>
                <li className={style.li}>Unwrap healthier <br /> <span> hydration this</span><span>holiday</span> </li>
                <p className={style.p}>Gift them best-in-class Nano Zero water <br /> filtration and PureVis™ technology.</p>
                <li className={style.li1}>Shop now</li>
                <li className={style.li2}></li>
                <div className={style.person_div}>
                    <TbDisabled onClick={() => setclick(click ? false : true)} className={style.person} />

                </div>

                <div className={style.disable_div}>
                    <div>
                        <HiOutlineXMark className='text-[30px]' />
                    </div>
                </div>

            </div>

        </div>
    )
}

export default Main