import React, { useState } from 'react'
import { BsChevronDown } from "react-icons/bs"
import logo from "../images/logo-larq.svg"
import { TbWorld } from "react-icons/tb"
import { FiShoppingCart } from "react-icons/fi"
import { FaBars } from "react-icons/fa"
import { Link } from "react-router-dom"

function Navbar() {

    const [click, setclick] = useState(false)


    const style = {
        litnav: " bg-[#153A5B] h-[32px] flex items-center justify-center max-md:hidden",
        p: "text-[18px] py-[2px] text-white",
        chdown: "text-[20px] text-[#99A9B8]",
        p2: "justify-center py-[30px] font-bold items-center flex ",
        p_div: " my-[5px] translate-x-[270px] absolute z-10 w-[60%] h-[230px] bg-[#00000099] rounded text-white hidden",
        nav: "nav fixed w-full h-[60px]  relative fixed max-md:h-[60px] w-[100%] ",
        img_logo: " w-[130px] h-[60px] translate-x-[-62px] translate-y-[4px] max-md:w-[90px] mx-[200px]",
        justify: "justify-around w-[550px] flex  text-[20px] font-bold text-[#153A5B] absolute right-6 top-4 tracking-wide  max-md:hidden",
        basket: "text-[30px] hover:cursor-pointer max-md:block",
        sidebar: `origin-top-right w-[580px] h-[700px] bg-[#153A5B] absolute right-[0px] top-[60px] z-10 text-white font-bold text-[20px] p-[40px]
        ${click ? 'scale-[1]' : 'scale-0'} duration-[.8s]`,
        line: "w-[450px] h-[10px] rounded bg-[#E5E5E5] mx-[40px] my-[20px]",
        spancha: "text-[15px] text-[#6F6D6A] px-[190px]",
        little_p: "text-[#5A666A] translate-x-[40px]",
        little_h1: "text-[30px] text-white flex justify-center items-center my-[80px]",
        li: "flex w-[500px] h-[60px] bg-white text-[#153A5B] justify-center items-center hover:bg-[#153A5B] cursor-pointer hover:text-white hover:border-[4px] border-white duration-500"
    }
    return (
        <div>
            {/* <div onMouseOver={MouseOver} className={style.litnav}>
                <p className={style.p}>Boo! Get up to 30% off Nano Zero filtration products with replacement filter plans! Learn more.</p>
                <BsChevronDown className={style.chdown} />
            </div> */}


            <div className={style.p_div}>

                <p className={style.p2}>
                    Subscribe and save with a replacement filter plan to get 20-30% off Nano Zero filtration products (LARQ Pitcher <br /> PureVis™ and LARQ Bottle Filtered)!

                    <br />

                    Prices as marked on eligible products with subscription to their respective replacement filter plans. <br />
                    Discount is automatically applied. No code required. No eligible on past purchases. Cannot be combined with other <br /> offers. Must purchase a subscription plan to receive a discount on the product(s) during this promotion. <br />
                    Offer valid through 11:59PM PT October 31, 2022.
                </p>

            </div>

            <nav className={style.nav}>
                <Link to="/">
                    <img className={style.img_logo} src={logo} alt="" />
                </Link>
                <FaBars className='text-[25px] translate-y-[-40px] hidden max-md:block mx-[20px] ' />


                <div className={style.justify}>
                    <span className='flex hover:text-[#8B827E] cursor-pointer'>Products <BsChevronDown className='my-[5px] mx-[2px] font-extrabold' /></span>
                    <span className='hover:text-[#8B827E] cursor-pointer'>Technology</span>
                    <span className='hover:text-[#8B827E] cursor-pointer'><Link to="/sign">
                        Sign in
                    </Link> </span>
                    <li className='flex'>
                        <span className='flex hover:text-[#8B827E] cursor-pointer'>EN <TbWorld className='my-1.5 text-[18px]' /></span>
                    </li>
                    <FiShoppingCart onClick={() => setclick(click ? false : true)} className={style.basket} />


                </div>
                <div className={style.sidebar}>
                    <span>Your Cart</span>
                    <p className={style.spancha}>$10 store credit</p>
                    <div className={style.line}><div></div></div>
                    <p className={style.little_p}>You're $200.00 away from $10 in store credit!</p>

                    <h1 className={style.little_h1}>Oh, it appears <br />

                        your cart is empty
                    </h1>
                    <li className={style.li}>SHOP LARQ</li>
                </div>
            </nav>


        </div >
    )
}

export default Navbar